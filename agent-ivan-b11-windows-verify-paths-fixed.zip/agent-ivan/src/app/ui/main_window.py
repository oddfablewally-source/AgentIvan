"""
Main application window.

This is the central GUI component. It:
- Provides menu bar, toolbar, and status bar.
- Hosts the chat interface (the example product functionality).
- Manages background workers for AI requests.
- Supports system tray integration.
- Handles clean shutdown (waiting for workers to finish).

The window receives an AppContext and uses its services. It does NOT
create services directly — that's the AppContext's job.
"""

from __future__ import annotations

from typing import Optional

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QAction, QIcon, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QSplitter,
    QSystemTrayIcon,
    QTextEdit,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from src.app.ai.provider import ProviderMessage
from src.app.core.app_context import AppContext
from src.app.core.logging_setup import get_logger
from src.app.core.paths import APP_NAME
from src.app.data.repositories import Conversation, Message
from src.app.ui.chat_worker import ChatWorker
from src.app.utils.helpers import format_timestamp

logger = get_logger("ui.main_window")


class MainWindow(QMainWindow):
    """
    Main application window with chat interface.
    """

    close_requested = Signal()

    def __init__(self, context: AppContext) -> None:
        super().__init__()
        self.ctx = context
        self._worker: Optional[ChatWorker] = None
        self._current_conversation: Optional[Conversation] = None
        self._tray_icon: Optional[QSystemTrayIcon] = None

        self._setup_window()
        self._setup_menu_bar()
        self._setup_toolbar()
        self._setup_central_widget()
        self._setup_status_bar()
        self._setup_system_tray()
        self._load_conversations()
        self._new_conversation()

    # --- Window setup ---

    def _setup_window(self) -> None:
        self.setWindowTitle(APP_NAME)
        self.resize(
            self.ctx.config.get("window_width", 900),
            self.ctx.config.get("window_height", 600),
        )
        self.setMinimumSize(600, 400)

    def _setup_menu_bar(self) -> None:
        menubar = self.menuBar()

        # File menu
        file_menu = menubar.addMenu("&File")

        self._new_action = QAction("&New Conversation", self)
        self._new_action.setShortcut("Ctrl+N")
        self._new_action.triggered.connect(self._new_conversation)
        file_menu.addAction(self._new_action)

        self._delete_action = QAction("&Delete Conversation", self)
        self._delete_action.triggered.connect(self._delete_conversation)
        file_menu.addAction(self._delete_action)

        file_menu.addSeparator()

        self._settings_action = QAction("&Settings...", self)
        self._settings_action.setShortcut("Ctrl+,")
        self._settings_action.triggered.connect(self._open_settings)
        file_menu.addAction(self._settings_action)

        file_menu.addSeparator()

        self._quit_action = QAction("&Quit", self)
        self._quit_action.setShortcut("Ctrl+Q")
        self._quit_action.triggered.connect(self.close)
        file_menu.addAction(self._quit_action)

        # Help menu
        help_menu = menubar.addMenu("&Help")

        self._about_action = QAction("&About", self)
        self._about_action.triggered.connect(self._open_about)
        help_menu.addAction(self._about_action)

    def _setup_toolbar(self) -> None:
        toolbar = self.addToolBar("Main")
        toolbar.setMovable(False)

        toolbar.addAction(self._new_action)

        self._send_button = QToolButton()
        self._send_button.setText("Send")
        self._send_button.clicked.connect(self._send_prompt)
        toolbar.addWidget(self._send_button)

        self._cancel_button = QToolButton()
        self._cancel_button.setText("Cancel")
        self._cancel_button.setEnabled(False)
        self._cancel_button.clicked.connect(self._cancel_request)
        toolbar.addWidget(self._cancel_button)

    def _setup_central_widget(self) -> None:
        """Create the main layout: conversation list + chat area."""
        splitter = QSplitter(Qt.Horizontal)

        # --- Left panel: conversation list ---
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)

        left_label = QLabel("Conversations")
        left_layout.addWidget(left_label)

        self._conversation_list = QListWidget()
        self._conversation_list.itemClicked.connect(self._on_conversation_selected)
        left_layout.addWidget(self._conversation_list)

        splitter.addWidget(left_panel)

        # --- Right panel: chat area ---
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)

        self._chat_display = QTextEdit()
        self._chat_display.setReadOnly(True)
        self._chat_display.setPlaceholderText("Start a conversation...")
        right_layout.addWidget(self._chat_display)

        # Input area
        input_layout = QHBoxLayout()
        self._prompt_input = QLineEdit()
        self._prompt_input.setPlaceholderText("Type your prompt here...")
        self._prompt_input.returnPressed.connect(self._send_prompt)
        input_layout.addWidget(self._prompt_input)

        send_btn = QToolButton()
        send_btn.setText("Send")
        send_btn.clicked.connect(self._send_prompt)
        input_layout.addWidget(send_btn)

        right_layout.addLayout(input_layout)

        splitter.addWidget(right_panel)
        splitter.setSizes([200, 700])

        self.setCentralWidget(splitter)

    def _setup_status_bar(self) -> None:
        self._status_label = QLabel("Ready")
        self.statusBar().addWidget(self._status_label)

    def _setup_system_tray(self) -> None:
        """Set up system tray icon if enabled in config."""
        if not self.ctx.config.get("system_tray", True):
            return

        # Create a simple icon (a colored square since we don't bundle a real icon)
        pixmap = QPixmap(32, 32)
        pixmap.fill(Qt.darkBlue)
        icon = QIcon(pixmap)

        self._tray_icon = QSystemTrayIcon(icon, self)
        self._tray_icon.setToolTip(APP_NAME)
        self._tray_icon.activated.connect(self._on_tray_activated)

        self._tray_icon.show()

    def _on_tray_activated(self, reason) -> None:
        """Handle system tray activation."""
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            if self.isVisible():
                self.hide()
            else:
                self.show()
                self.raise_()
                self.activateWindow()

    # --- Conversation management ---

    def _load_conversations(self) -> None:
        """Load all conversations into the list widget."""
        self._conversation_list.clear()
        conversations = self.ctx.conversations.list_all()
        for conv in conversations:
            item = QListWidgetItem(conv.title)
            item.setData(Qt.UserRole, conv.id)
            self._conversation_list.addItem(item)

    def _new_conversation(self) -> None:
        """Create a new conversation and select it."""
        conv = self.ctx.conversations.create(title="New Conversation")
        self._current_conversation = conv
        self._load_conversations()
        self._select_conversation(conv.id)
        self._chat_display.clear()
        self._prompt_input.setFocus()

    def _delete_conversation(self) -> None:
        """Delete the current conversation."""
        if self._current_conversation is None:
            return
        conv_id = self._current_conversation.id
        self.ctx.conversations.delete(conv_id)
        self._current_conversation = None
        self._chat_display.clear()
        self._load_conversations()
        self._status_label.setText("Conversation deleted.")

    def _select_conversation(self, conv_id: int) -> None:
        """Select a conversation in the list and load its messages."""
        for i in range(self._conversation_list.count()):
            item = self._conversation_list.item(i)
            if item.data(Qt.UserRole) == conv_id:
                self._conversation_list.setCurrentRow(i)
                break

        conv = self.ctx.conversations.get_by_id(conv_id)
        if conv:
            self._current_conversation = conv
            self._display_messages(conv_id)

    def _on_conversation_selected(self, item: QListWidgetItem) -> None:
        """Handle conversation list item click."""
        conv_id = item.data(Qt.UserRole)
        self._select_conversation(conv_id)

    def _display_messages(self, conv_id: int) -> None:
        """Display all messages from a conversation in the chat area."""
        self._chat_display.clear()
        messages = self.ctx.messages.list_by_conversation(conv_id)
        for msg in messages:
            self._append_message(msg.role, msg.content, msg.created_at)

    def _append_message(
        self, role: str, content: str, timestamp: str = ""
    ) -> None:
        """Append a message to the chat display."""
        role_label = {
            "user": "You",
            "assistant": "Assistant",
            "system": "System",
        }.get(role, role.capitalize())

        ts = format_timestamp(timestamp) if timestamp else ""

        html = f'<p><b style="color: #89b4fa;">{role_label}</b>'
        if ts:
            html += f' <span style="color: #585b70; font-size: 11px;">{ts}</span>'
        html += f'</p><p style="white-space: pre-wrap;">{content}</p><hr>'
        self._chat_display.append(html)

    # --- Chat / AI request handling ---

    def _send_prompt(self) -> None:
        """Send the current prompt to Ollama and display the response."""
        # Don't allow sending if a worker is already running
        if self._worker is not None and self._worker.isRunning():
            return

        prompt_text = self._prompt_input.text().strip()
        if not prompt_text:
            return

        if self._current_conversation is None:
            self._new_conversation()

        conv_id = self._current_conversation.id

        # Save the user message
        user_msg = self.ctx.messages.add(conv_id, "user", prompt_text)
        self._append_message(user_msg.role, user_msg.content, user_msg.created_at)

        # Update conversation title if it's the first message
        if self.ctx.messages.count() <= 1 or len(self.ctx.messages.list_by_conversation(conv_id)) <= 1:
            title = prompt_text[:50] + ("..." if len(prompt_text) > 50 else "")
            self.ctx.conversations.update_title(conv_id, title)
            self._current_conversation.title = title
            self._load_conversations()
            self._select_conversation(conv_id)

        # Clear input
        self._prompt_input.clear()

        # Prepare chat history
        history = self.ctx.messages.list_by_conversation(conv_id)
        chat_messages = [
            ProviderMessage(
                role=m.role, content=m.content
            )
            for m in history
        ]

        # Add assistant placeholder message
        assistant_msg = self.ctx.messages.add(conv_id, "assistant", "")
        self._append_message("assistant", "", assistant_msg.created_at)

        # Set up the worker
        system_prompt = self.ctx.config.get("system_prompt", "")
        self._worker = ChatWorker(
            self.ctx.chat_provider,
            chat_messages,
            system_prompt=system_prompt,
        )

        # Connect signals
        self._worker.token_received.connect(
            lambda token: self._update_last_message(token, conv_id, assistant_msg.id)
        )
        self._worker.finished_success.connect(
            lambda resp: self._on_chat_success(resp, conv_id, assistant_msg.id)
        )
        self._worker.failed.connect(
            lambda err: self._on_chat_failed(err, conv_id, assistant_msg.id)
        )
        self._worker.finished.connect(self._on_worker_finished)

        # Update UI state
        self._send_button.setEnabled(False)
        self._cancel_button.setEnabled(True)
        self._status_label.setText("Generating response...")

        # Start the worker thread
        self._worker.start()

    def _update_last_message(self, token: str, conv_id: int, msg_id: int) -> None:
        """Update the last message in the chat display with a new token."""
        cursor = self._chat_display.textCursor()
        cursor.movePosition(cursor.End)
        cursor.insertText(token)

    def _on_chat_success(self, response: str, conv_id: int, msg_id: int) -> None:
        """Handle successful chat completion."""
        # Update the assistant message in the database with the full response
        self._update_message_content(msg_id, response)
        self._status_label.setText("Response complete.")
        self._reload_conversation(conv_id)

    def _on_chat_failed(self, error: str, conv_id: int, msg_id: int) -> None:
        """Handle chat failure."""
        self._update_message_content(msg_id, f"[Error: {error}]")
        self._status_label.setText(f"Error: {error}")
        QMessageBox.warning(self, "AI Request Failed", error)

    def _on_worker_finished(self) -> None:
        """Clean up after worker thread completes (success or failure)."""
        self._send_button.setEnabled(True)
        self._cancel_button.setEnabled(False)
        # The worker thread object will be cleaned up by Qt's parent mechanism
        if self._worker:
            self._worker.deleteLater()
            self._worker = None

    def _cancel_request(self) -> None:
        """Request cancellation of the current AI request."""
        if self._worker and self._worker.isRunning():
            self._worker.requestInterruption()
            self._status_label.setText("Cancelling...")
            self._cancel_button.setEnabled(False)

    def _update_message_content(self, msg_id: int, content: str) -> None:
        """Update a message's content in the database."""
        self.ctx.messages.update_content(msg_id, content)

    def _reload_conversation(self, conv_id: int) -> None:
        """Reload the conversation display."""
        self._display_messages(conv_id)

    # --- Dialogs ---

    def _open_settings(self) -> None:
        """Open the settings dialog."""
        from src.app.ui.settings_dialog import SettingsDialog

        dialog = SettingsDialog(self.ctx.config, self)
        if dialog.exec():
            # Settings were saved; reload Ollama service config
            self._status_label.setText("Settings updated.")
            # Reload conversation list in case nothing else changed
            self._load_conversations()

    def _open_about(self) -> None:
        """Open the about dialog."""
        from src.app.ui.about_dialog import AboutDialog

        dialog = AboutDialog(self)
        dialog.exec()

    # --- Window close / shutdown ---

    def closeEvent(self, event) -> None:
        """
        Handle window close event.

        Ensures background workers are properly stopped before the
        application exits. This prevents hangs and resource leaks.
        """
        # Save window geometry
        self.ctx.config.set("window_width", self.width())
        self.ctx.config.set("window_height", self.height())

        # Stop any running worker
        if self._worker and self._worker.isRunning():
            logger.info("Waiting for worker thread to finish...")
            self._worker.requestInterruption()
            self._worker.wait(5000)  # Wait up to 5 seconds
            if self._worker.isRunning():
                logger.warning("Worker did not stop within timeout.")

        # Hide tray icon
        if self._tray_icon:
            self._tray_icon.hide()

        # Shutdown context (closes DB connections)
        self.ctx.shutdown()

        event.accept()
