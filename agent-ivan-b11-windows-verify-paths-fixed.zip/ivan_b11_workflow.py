"""Brick 11 real-workflow verification (portable: Linux and Windows).

Exercises the complete AgentIvan lifecycle through the public
ProjectService facade on a real temporary workspace: create, intake
(text/file/reference), inspect, extract, reconcile, query, export
(Markdown/PDF/snapshot), reload, and persistence confirmation.

Run with the packaged agent-ivan venv python from the package root:

    Windows:  agent-ivan\\.venv\\Scripts\\python ivan_b11_workflow.py
    Linux:    agent-ivan/.venv/bin/python ivan_b11_workflow.py

The script locates the packaged agent-ivan checkout relative to its own
file location, so the whole package may be moved to any directory.
No PYTHONPATH manipulation is required.

Pure Python + product code. Exit 0 only if every check passes.
"""

from __future__ import annotations

import hashlib
import io
import sys
import tempfile
import zipfile
from pathlib import Path

# Portable: the packaged agent-ivan checkout sits next to this script.
# Resolved from this file's own location, so the entire verification
# package may be moved to an arbitrary directory on any OS.
_PACKAGE_ROOT = Path(__file__).resolve().parent
_AGENT_IVAN_ROOT = _PACKAGE_ROOT / "agent-ivan"
if not (_AGENT_IVAN_ROOT / "src" / "app" / "product" / "agentivan").is_dir():
    raise SystemExit(
        "agent-ivan checkout not found next to this script: "
        f"expected {_AGENT_IVAN_ROOT}"
    )
sys.path.insert(0, str(_AGENT_IVAN_ROOT))

from src.app.product.agentivan import (  # noqa: E402
    AgentIvanWorkspace,
    BuildPackQuery,
    KEEP_EXISTING,
    Project,
    ProjectService,
)
from src.app.product.agentivan.reconciliation import (  # noqa: E402
    _CATEGORY_SECTION_FIELD,
)

PASS = True


def check(name: str, cond: bool, detail: str = "") -> None:
    global PASS
    if not cond:
        PASS = False
    print(f"{'PASS' if cond else 'FAIL'}  {name}" + (f"  [{detail}]" if detail else ""))


def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="ivan-b11-"))
    print(f"workspace root: {tmp}")

    # -- module / application startup ------------------------------------
    import src.app.product.agentivan as pkg

    check("module startup (package import)", hasattr(pkg, "ProjectService"))

    # -- workspace + project lifecycle ------------------------------------
    ws = AgentIvanWorkspace(tmp / "ws")
    check("workspace created", (tmp / "ws" / "projects").is_dir())

    svc = ProjectService.create(ws, "Brick 11 Rig — café ☃")
    pid = svc.project_id
    check("project created", isinstance(pid, str) and len(pid) == 32, pid[:8])

    opened = svc.open_project(pid)
    check("open project", opened.project_id == pid and ws.active_project_id == pid)
    loaded = svc.load_project(pid)
    check("load project", loaded.project_id == pid)

    # -- intake ------------------------------------------------------------
    rec_t = svc.add_text(
        "Seat height measured at 28 inches.\nPart: steel bracket\nTODO: paint color\n",
        label="Session notes",
    )
    check("add text", rec_t.label == "Session notes", rec_t.source_id[:8])

    src_file = tmp / "spécifications ☃.md"
    src_file.write_text("# Spécifications\nDétail: café ☃\n", encoding="utf-8")
    rec_f = svc.add_file(src_file, label="Unicode file")
    check("add file", rec_f.kind.value == "file", rec_f.source_id[:8])

    rec_r = svc.add_reference("https://example.invalid/rig/blueprint", label="Blueprint")
    check("add reference", rec_r.kind.value == "reference", rec_r.source_id[:8])

    # -- inspection ---------------------------------------------------------
    sources = svc.list_sources()
    check("inspect sources", len(sources) == 3, f"{len(sources)} sources")
    check(
        "source integrity",
        all(svc.verify_source(s.source_id).state.value == "intact" for s in sources),
    )
    check(
        "search sources (metadata)",
        any(s.source_id == rec_f.source_id for s in svc.search_sources("Unicode")),
    )

    # -- extraction ----------------------------------------------------------
    eset = svc.extract()
    items = eset.all_items()
    check(
        "deterministic extraction",
        len(items) > 0
        and {r.extractor_name for r in eset.results} == {"deterministic"},
        f"{len(items)} items",
    )
    check("extraction persisted", svc.get_extraction_set() == eset)

    # -- reconciliation -------------------------------------------------------
    added = svc.import_candidates()
    check("import candidates", len(added) > 0, f"{len(added)} candidates")
    acceptable = [c for c in svc.pending_candidates() if c.category in _CATEGORY_SECTION_FIELD]
    check("pending candidates", len(acceptable) >= 4, f"{len(acceptable)} acceptable")

    # Accept the measurement candidate so downstream query/export checks have
    # a deterministic needle ("28 inches") to look for.
    measure = next(c for c in acceptable if "28 inches" in c.text)
    others = [c for c in acceptable if c.reconciliation_id != measure.reconciliation_id]

    record = svc.accept_candidate(measure.reconciliation_id, note="b11 accept")
    check("accept candidate", record is not None, record.record_id[:12] if record else "")
    svc.reject_candidate(others[0].reconciliation_id, reason="b11 reject")
    check(
        "reject candidate",
        svc.get_candidate(others[0].reconciliation_id).state.value == "rejected",
    )
    svc.defer_candidate(others[1].reconciliation_id, reason="b11 defer")
    check(
        "defer candidate",
        svc.get_candidate(others[1].reconciliation_id).state.value == "deferred",
    )
    contradiction = svc.flag_contradiction(
        others[2].reconciliation_id, description="b11 conflict"
    )
    resolved = svc.resolve_contradiction(
        contradiction.contradiction_id, resolution=KEEP_EXISTING, note="b11 stands"
    )
    check("flag+resolve contradiction", resolved.state.value == "RESOLVED")

    # -- query / knowledge ------------------------------------------------------
    pack = svc.get_build_pack()
    check("build pack retrieved", len(pack.sections) > 0, f"{len(pack.sections)} sections")
    hits = svc.search("28 inches")
    check("search knowledge", len(hits) > 0, f"{len(hits)} hits")
    known = svc.what_do_we_know().to_dict()
    check("what_do_we_know", sum(len(v) for v in known.values()) > 0)
    remaining = svc.what_remains().to_dict()
    check("what_remains", isinstance(remaining, dict))
    check(
        "query equals lower layer",
        [h.to_dict() for h in svc.query(text="28 inches")]
        == [h.to_dict() for h in BuildPackQuery.for_project(svc.project).records(text="28 inches")],
    )

    # -- exports ------------------------------------------------------------------
    md_path = tmp / "pack.md"
    svc.export_markdown(md_path)
    md_bytes = md_path.read_bytes()
    check("export Markdown", md_path.is_file() and len(md_bytes) > 500, f"{len(md_bytes)} bytes")
    check("markdown content", "Brick 11 Rig" in md_bytes.decode("utf-8") and "28 inches" in md_bytes.decode("utf-8"))

    pdf_path = tmp / "pack.pdf"
    svc.export_pdf(pdf_path)
    pdf_bytes = pdf_path.read_bytes()
    check("export PDF", pdf_bytes.startswith(b"%PDF") and len(pdf_bytes) > 2000, f"{len(pdf_bytes)} bytes")

    snap1 = svc.export_snapshot()
    snap2 = svc.export_snapshot()
    check("export snapshot deterministic", snap1.data == snap2.data, f"{len(snap1.data)} bytes")
    with zipfile.ZipFile(io.BytesIO(snap1.data)) as zf:
        names = zf.namelist()
    check("snapshot manifest first", names[0] == "manifest.json")

    snap_file = tmp / "rig.zip"
    svc.export_snapshot(snap_file)
    check("snapshot to file", snap_file.is_file())

    # -- reload + persistence -------------------------------------------------------
    json_before = hashlib.sha256(svc.project.project_json_path.read_bytes()).hexdigest()
    pack_before = svc.get_build_pack().to_dict()
    known_before = svc.what_do_we_know().to_dict()

    svc2 = ProjectService(ws, project_id=pid)  # fresh bind = reload
    check("reload project", svc2.project_id == pid)
    check(
        "persisted state intact",
        hashlib.sha256(svc2.project.project_json_path.read_bytes()).hexdigest() == json_before
        and svc2.get_build_pack().to_dict() == pack_before
        and svc2.what_do_we_know().to_dict() == known_before
        and [s.source_id for s in svc2.list_sources()] == [s.source_id for s in sources],
    )
    reloaded = Project.load(svc.project.root)
    check("Project.load round-trip", reloaded.project_id == pid and len(reloaded.sources) == 3)

    # -- snapshot import round-trip ----------------------------------------------------
    restored = ProjectService.import_snapshot(snap1.data, tmp / "restored")
    check("snapshot import", restored.project_id == pid)
    svc3 = ProjectService(ws, project=restored)
    check(
        "restored state matches",
        svc3.what_do_we_know().to_dict() == known_before,
    )

    print()
    print("WORKFLOW:", "ALL CHECKS PASSED" if PASS else "FAILURES PRESENT")
    return 0 if PASS else 1


if __name__ == "__main__":
    sys.exit(main())
