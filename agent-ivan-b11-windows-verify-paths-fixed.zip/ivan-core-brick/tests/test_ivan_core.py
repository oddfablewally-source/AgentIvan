"""
Minimal verification test — Ivan Core Brick 1.

Proves, with no network / no Ollama server / no GUI / no database:

1. The agent receives a message and returns a response (the core contract).
2. The provider boundary is respected (agent talks only to ChatProvider).
3. Configuration is separated (custom IvanConfig changes the system prompt;
   agent never reads global state).
4. Error handling is explicit (empty input -> IvanChatError,
   provider failure -> IvanProviderError, bad construction -> IvanConfigError).
"""

from __future__ import annotations

import pytest

from src.app.product.ivan.agent import IvanAgent
from src.app.product.ivan.config import IvanConfig
from src.app.product.ivan.errors import (
    IvanChatError,
    IvanConfigError,
    IvanError,
    IvanProviderError,
)
from src.app.product.ivan.identity import DEFAULT_IDENTITY
from src.app.product.ivan.provider import ChatProvider, ProviderMessage
from src.app.product.ivan.rules import CORE_RULES


class FakeProvider:
    """In-memory ChatProvider: no network, deterministic responses."""

    def __init__(self, reply: str = "Hello from Ivan.") -> None:
        self.reply = reply
        self.calls: list[tuple[list[ProviderMessage], str | None]] = []

    def chat(
        self,
        messages: list[ProviderMessage],
        system_prompt: str | None = None,
    ) -> str:
        self.calls.append((messages, system_prompt))
        user_text = messages[-1].content if messages else ""
        return f"{self.reply} You said: {user_text}"


class FailingProvider:
    """Simulates a provider-side outage."""

    def chat(self, messages, system_prompt=None) -> str:
        raise IvanProviderError("simulated provider outage")


class ExplodingProvider:
    """Simulates a non-conforming provider raising an unexpected error."""

    def chat(self, messages, system_prompt=None) -> str:
        raise RuntimeError("boom")


def test_chat_receives_message_and_returns_response() -> None:
    """Core contract: chat(message) -> response, via the provider boundary."""
    provider = FakeProvider()
    agent = IvanAgent(provider=provider)

    response = agent.chat("Hello, Ivan.")

    assert "Hello, Ivan." in response
    assert isinstance(provider, ChatProvider)  # protocol satisfied

    # The agent actually routed through the provider exactly once.
    assert len(provider.calls) == 1
    sent_messages, sent_system_prompt = provider.calls[0]
    assert sent_messages[0].role == "user"
    assert sent_messages[0].content == "Hello, Ivan."
    # Identity + rules are compiled into the system prompt.
    assert DEFAULT_IDENTITY.name in sent_system_prompt
    assert CORE_RULES[0] in sent_system_prompt


def test_configuration_is_separate_from_logic() -> None:
    """Custom config changes behavior without touching agent code."""
    provider = FakeProvider()
    config = IvanConfig(system_prompt="Custom base prompt.", provider_name="fake")
    agent = IvanAgent(provider=provider, config=config)

    agent.chat("hi")
    _, sent_system_prompt = provider.calls[0]
    assert sent_system_prompt.startswith("Custom base prompt.")
    # Rules still appended after the custom base.
    assert CORE_RULES[0] in sent_system_prompt

    # from_mapping: the seam where app-level config becomes IvanConfig.
    cfg2 = IvanConfig.from_mapping(
        {"system_prompt": "Mapped prompt.", "provider_name": "fake"}
    )
    assert cfg2.system_prompt == "Mapped prompt."


def test_chat_rejects_empty_message() -> None:
    agent = IvanAgent(provider=FakeProvider())
    with pytest.raises(IvanChatError):
        agent.chat("   ")
    with pytest.raises(IvanChatError):
        agent.chat(123)  # type: ignore[arg-type]


def test_provider_failure_surfaces_as_ivan_provider_error() -> None:
    agent = IvanAgent(provider=FailingProvider())
    with pytest.raises(IvanProviderError):
        agent.chat("hello")


def test_unexpected_provider_error_is_normalized() -> None:
    """Callers only ever see IvanError subtypes, never raw provider errors."""
    agent = IvanAgent(provider=ExplodingProvider())
    with pytest.raises(IvanError):
        agent.chat("hello")


def test_construction_validates_its_inputs() -> None:
    with pytest.raises(IvanConfigError):
        IvanAgent(provider=None)  # type: ignore[arg-type]
    with pytest.raises(IvanConfigError):
        IvanAgent(provider=object())  # does not satisfy ChatProvider
    with pytest.raises(IvanConfigError):
        IvanAgent(provider=FakeProvider(), config="nope")  # type: ignore[arg-type]
