"""
Error types — Brick 1.

One base exception plus one per failure domain, so callers can catch
precisely what they can handle:

- IvanConfigError   — bad configuration / construction-time misuse.
- IvanChatError     — bad chat input (empty message, wrong type).
- IvanProviderError — the model provider failed (network, model missing,
                      timeout, malformed response).

IvanError is the common base: `except IvanError` catches everything
this brick raises.
"""

from __future__ import annotations


class IvanError(Exception):
    """Base exception for everything the Ivan core agent layer raises."""


class IvanConfigError(IvanError):
    """Raised when the agent is misconfigured or misconstructed."""


class IvanChatError(IvanError):
    """Raised when chat input is invalid (empty message, wrong type)."""


class IvanProviderError(IvanError):
    """Raised when the model provider fails to produce a response."""
