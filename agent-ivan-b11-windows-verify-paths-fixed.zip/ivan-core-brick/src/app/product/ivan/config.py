"""
Configuration — Brick 1.

Configuration is data, supplied at construction time. The agent never
reads global state, environment variables, or config files itself.
Callers build an IvanConfig (from defaults, from the boilerplate's
ConfigManager, or by hand) and pass it in.

This keeps the "configuration separated from application logic" requirement
literal: `agent.py` contains zero config-file I/O.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True)
class IvanConfig:
    """
    Agent-level settings.

    Attributes:
        system_prompt: Base system prompt. If None, the agent derives one
            from the IvanIdentity plus CORE_RULES.
        provider_name: Human-readable label for the active provider
            (e.g. "ollama", "fake"). Informational only.
        extra: Escape hatch for future provider options. Brick 1 ignores it;
            it exists so later bricks can extend config without changing
            this dataclass's shape.
    """

    system_prompt: str | None = None
    provider_name: str = "unspecified"
    extra: Mapping[str, Any] | None = None

    @classmethod
    def from_mapping(cls, mapping: Mapping[str, Any]) -> "IvanConfig":
        """
        Build config from a plain mapping (e.g. parsed JSON, or a dict
        pulled from the boilerplate's ConfigManager).

        Recognized keys: "system_prompt", "provider_name", "extra".
        Unknown keys are ignored so older configs keep working.
        """
        if not isinstance(mapping, Mapping):
            from src.app.product.ivan.errors import IvanConfigError

            raise IvanConfigError(
                f"IvanConfig.from_mapping() requires a mapping, "
                f"got {type(mapping).__name__}."
            )
        system_prompt = mapping.get("system_prompt", None)
        if system_prompt is not None and not isinstance(system_prompt, str):
            from src.app.product.ivan.errors import IvanConfigError

            raise IvanConfigError("IvanConfig 'system_prompt' must be a string.")
        return cls(
            system_prompt=system_prompt,
            provider_name=str(mapping.get("provider_name", "unspecified")),
            extra=mapping.get("extra"),
        )
