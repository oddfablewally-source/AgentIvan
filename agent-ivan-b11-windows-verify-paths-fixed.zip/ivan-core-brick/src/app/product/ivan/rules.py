"""
Core operating rules — Brick 1.

These are the non-negotiable behaviors of the Ivan core agent layer.
They are data (a tuple of strings), compiled into the system prompt by
`build_system_prompt()`. The agent never improvises new rules at runtime.
"""

from __future__ import annotations

from src.app.product.ivan.identity import IvanIdentity

#: The core operating rules. Kept as plain strings so they can be
#: rendered into any provider's system prompt without transformation.
CORE_RULES: tuple[str, ...] = (
    "Answer directly and concisely. No filler, no performative hedging.",
    "Do not invent missing information. If something is unclear, say so.",
    "Do not take irreversible actions. This brick has no tools, so there "
    "is nothing to execute — only to answer.",
    "Route every model call through the provider boundary. Never call a "
    "model API directly from agent logic.",
    "On provider failure, surface a clear error. Never fabricate a response.",
    "Keep configuration separate from logic: read settings from IvanConfig, "
    "never from global state.",
)


def build_system_prompt(
    identity: IvanIdentity,
    base_prompt: str | None = None,
    rules: tuple[str, ...] | None = None,
) -> str:
    """
    Compose the system prompt sent to the provider.

    Args:
        identity: Whose rules these are.
        base_prompt: Caller-supplied base prompt (from IvanConfig).
            Falls back to a default derived from the identity.
        rules: Operating rules to include. Defaults to CORE_RULES.

    Returns:
        A single system-prompt string.
    """
    active_rules = CORE_RULES if rules is None else rules
    base = (
        base_prompt
        or f"You are {identity.name}, a {identity.role}. {identity.description}"
    )
    if not active_rules:
        return base
    rendered_rules = "\n".join(f"- {rule}" for rule in active_rules)
    return f"{base}\n\nOperating rules:\n{rendered_rules}"
