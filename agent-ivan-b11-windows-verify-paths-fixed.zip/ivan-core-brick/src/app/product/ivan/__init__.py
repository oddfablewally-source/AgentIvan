"""
Ivan Core — Brick 1: core agent layer.

Scope (deliberately narrow):
- Ivan identity
- Core operating rules
- Clean model/provider boundary (agent depends only on the
  ChatProvider protocol, never on a concrete model API)
- Callable chat() interface
- Configuration separated from application logic
- Clear error handling

What this brick does NOT include (by design):
- No UI, no authentication, no databases, no memory systems.

Location rationale (documented, per project rules):
The boilerplate reserves `src/app/product/` for product-specific code and
asks that the generic foundation (`core/`, `ai/`, `data/`, `ui/`) stay
untouched. Ivan Core is product code, so it lives in
`src/app/product/ivan/` as a self-contained subpackage. No existing files
were modified and no architectural patterns were changed.
"""

from src.app.product.ivan.agent import IvanAgent
from src.app.product.ivan.config import IvanConfig
from src.app.product.ivan.errors import (
    IvanChatError,
    IvanConfigError,
    IvanError,
    IvanProviderError,
)
from src.app.product.ivan.identity import DEFAULT_IDENTITY, IvanIdentity
from src.app.product.ivan.provider import (
    ChatProvider,
    OllamaChatProvider,
    ProviderMessage,
)
from src.app.product.ivan.rules import CORE_RULES, build_system_prompt

__all__ = [
    "IvanAgent",
    "IvanConfig",
    "IvanError",
    "IvanChatError",
    "IvanConfigError",
    "IvanProviderError",
    "IvanIdentity",
    "DEFAULT_IDENTITY",
    "ChatProvider",
    "OllamaChatProvider",
    "ProviderMessage",
    "CORE_RULES",
    "build_system_prompt",
]
