"""
Ivan core agent — Brick 1.

A thin, stateless agent layer:

    provider: ChatProvider   # the ONLY model access (protocol, not concrete)
    config:   IvanConfig     # settings, supplied at construction
    identity: IvanIdentity   # who Ivan is
    rules:    tuple[str,...] # operating rules, default CORE_RULES

Public surface: `chat(message) -> str`.

Deliberately absent in Brick 1: UI, auth, databases, memory, tools,
streaming, multi-turn history. `chat()` takes one message and returns one
response. Later bricks may add history without changing this contract.
"""

from __future__ import annotations

from src.app.product.ivan.config import IvanConfig
from src.app.product.ivan.errors import IvanChatError, IvanConfigError, IvanProviderError
from src.app.product.ivan.identity import DEFAULT_IDENTITY, IvanIdentity
from src.app.product.ivan.provider import ChatProvider, ProviderMessage
from src.app.product.ivan.rules import CORE_RULES, build_system_prompt


class IvanAgent:
    """
    The Ivan core agent.

    Args:
        provider: Any object satisfying the ChatProvider protocol.
        config: Agent settings. Defaults to IvanConfig() (all defaults).
        identity: Who Ivan is. Defaults to DEFAULT_IDENTITY.
        rules: Operating rules. Defaults to CORE_RULES. Pass () to send
            no rules (useful in tests).

    Raises:
        IvanConfigError: if provider is missing or config/identity/rules
            have the wrong types.
    """

    def __init__(
        self,
        provider: ChatProvider,
        config: IvanConfig | None = None,
        identity: IvanIdentity | None = None,
        rules: tuple[str, ...] | None = None,
    ) -> None:
        if provider is None:
            raise IvanConfigError("IvanAgent requires a provider.")
        if not isinstance(provider, ChatProvider):
            raise IvanConfigError(
                "IvanAgent provider must satisfy the ChatProvider protocol "
                f"(needs chat(messages, system_prompt) -> str); "
                f"got {type(provider).__name__}."
            )
        self._provider = provider

        if config is None:
            config = IvanConfig()
        if not isinstance(config, IvanConfig):
            raise IvanConfigError(
                f"IvanAgent config must be an IvanConfig; got {type(config).__name__}."
            )
        self._config = config

        if identity is None:
            identity = DEFAULT_IDENTITY
        if not isinstance(identity, IvanIdentity):
            raise IvanConfigError(
                f"IvanAgent identity must be an IvanIdentity; "
                f"got {type(identity).__name__}."
            )
        self._identity = identity

        if rules is None:
            rules = CORE_RULES
        if not isinstance(rules, tuple) or not all(isinstance(r, str) for r in rules):
            raise IvanConfigError("IvanAgent rules must be a tuple of strings.")
        self._rules = rules

        # Compose once: identity + config + rules -> system prompt.
        self._system_prompt = build_system_prompt(
            identity=self._identity,
            base_prompt=self._config.system_prompt,
            rules=self._rules,
        )

    # --- Introspection (read-only, no mutation) ---

    @property
    def identity(self) -> IvanIdentity:
        return self._identity

    @property
    def rules(self) -> tuple[str, ...]:
        return self._rules

    @property
    def system_prompt(self) -> str:
        """The composed system prompt actually sent to the provider."""
        return self._system_prompt

    # --- The one public action ---

    def chat(self, message: str) -> str:
        """
        Send a single user message to the provider and return its response.

        Args:
            message: Non-empty user message.

        Returns:
            The provider's response text.

        Raises:
            IvanChatError: message is not a non-empty string.
            IvanProviderError: the provider failed or returned unusable output.
        """
        if not isinstance(message, str):
            raise IvanChatError(
                f"chat() message must be a string; got {type(message).__name__}."
            )
        if not message.strip():
            raise IvanChatError("chat() message must not be empty.")

        provider_messages = [ProviderMessage(role="user", content=message)]
        try:
            response = self._provider.chat(
                provider_messages,
                system_prompt=self._system_prompt,
            )
        except IvanProviderError:
            raise
        except Exception as e:
            # A non-conforming provider raised something unexpected:
            # normalize it so callers only ever see IvanError subtypes.
            raise IvanProviderError(f"Provider failed unexpectedly: {e}") from e

        if not isinstance(response, str):
            raise IvanProviderError(
                f"Provider returned {type(response).__name__}; expected str."
            )
        if not response.strip():
            raise IvanProviderError("Provider returned an empty response.")
        return response
