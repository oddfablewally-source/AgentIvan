"""
Model/provider boundary — Brick 1.

The agent depends ONLY on the `ChatProvider` protocol defined here.
It never imports Ollama, requests, or any concrete model SDK.

- `ProviderMessage`: the single message shape crossing the boundary.
- `ChatProvider`: the protocol. Any object with a matching `chat()`
  method satisfies it (duck-typing friendly, `runtime_checkable`).
- `OllamaChatProvider`: the one sanctioned adapter that wraps the
  boilerplate's existing `OllamaService` without changing it. This is how
  Ivan talks to a real model while keeping the boundary clean.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from src.app.product.ivan.errors import IvanProviderError


@dataclass(frozen=True)
class ProviderMessage:
    """A single message crossing the provider boundary."""

    role: str  # "user" | "assistant" | "system"
    content: str


@runtime_checkable
class ChatProvider(Protocol):
    """Minimal contract any model provider must satisfy."""

    def chat(
        self,
        messages: list[ProviderMessage],
        system_prompt: str | None = None,
    ) -> str:
        """
        Return the provider's complete response text for the messages.

        Raises:
            IvanProviderError: on any provider-side failure.
        """
        ...


class OllamaChatProvider:
    """
    Adapter from the boilerplate's OllamaService to the ChatProvider protocol.

    The adapter is the ONLY place that knows about OllamaService's types
    (its ChatMessage, its exception hierarchy). Agent code never touches them.
    """

    def __init__(self, ollama_service: object) -> None:
        if ollama_service is None:
            raise IvanProviderError("OllamaChatProvider requires an OllamaService.")
        # Duck-typed on purpose: we only need `.chat(messages, system_prompt)`.
        if not hasattr(ollama_service, "chat"):
            raise IvanProviderError(
                "OllamaChatProvider requires an object with a chat() method."
            )
        self._service = ollama_service

    def chat(
        self,
        messages: list[ProviderMessage],
        system_prompt: str | None = None,
    ) -> str:
        # Local import: keeps this module importable without the ai package
        # unless the adapter is actually used.
        from src.app.ai.ollama_service import ChatMessage as OllamaChatMessage
        from src.app.ai.ollama_service import OllamaError

        ollama_messages = [
            OllamaChatMessage(role=m.role, content=m.content) for m in messages
        ]
        try:
            return self._service.chat(ollama_messages, system_prompt=system_prompt)
        except OllamaError as e:
            raise IvanProviderError(f"Ollama provider failed: {e}") from e
        except IvanProviderError:
            raise
        except Exception as e:  # Defensive: never leak unknown errors raw.
            raise IvanProviderError(f"Ollama provider failed unexpectedly: {e}") from e
