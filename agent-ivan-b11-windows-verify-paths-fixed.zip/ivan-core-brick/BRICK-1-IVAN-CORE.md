# Ivan Core — Brick 1: Core Agent Layer

Status: complete and verified (`tests/test_ivan_core.py`, 6/6 passing).

## What was built

A self-contained subpackage at `src/app/product/ivan/` — the boilerplate
reserves `src/app/product/` for product code, so no existing files were
modified and no architecture was redesigned.

| File | Responsibility |
|---|---|
| `identity.py` | `IvanIdentity` dataclass + `DEFAULT_IDENTITY` — single source of truth for who Ivan is |
| `rules.py` | `CORE_RULES` (6 operating rules) + `build_system_prompt()` |
| `provider.py` | `ChatProvider` protocol (the model boundary), `ProviderMessage`, and `OllamaChatProvider` — the one sanctioned adapter wrapping the boilerplate's existing `OllamaService` without changing it |
| `config.py` | `IvanConfig` dataclass (frozen) + `from_mapping()` seam for app-level config; agent never reads global state |
| `agent.py` | `IvanAgent` with the single public method `chat(message: str) -> str` |
| `errors.py` | `IvanError` base + `IvanConfigError` / `IvanChatError` / `IvanProviderError` |

## Deliberately excluded (per brief)

No UI, no authentication, no databases, no memory/history, no tools.
`chat()` is stateless: one message in, one response out.

## How to verify

```bash
python -m pytest tests/test_ivan_core.py -v --noconftest
```

(`--noconftest` because the boilerplate's shared `conftest.py` imports
PySide6 for the GUI/db tests; this brick is intentionally independent of
all of that — no network, no Ollama server, no GUI, no database.)

## Suggested next bricks (not started)

- Brick 2: multi-turn conversation handling (still no persistence)
- Brick 3: wiring `IvanAgent` + `OllamaChatProvider` into `AppContext`
- Later: persistence, memory, tools — each as its own brick
